package com.cg.mypaymentapp.spring.MyPaymentAppSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPaymentAppSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPaymentAppSpringApplication.class, args);
	}
}
